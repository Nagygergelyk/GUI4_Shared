﻿using ArmyEditor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArmyEditor.Services
{
    public interface ITrooperEditorService
    {
        void Edit(Trooper trooper);
    }
}
